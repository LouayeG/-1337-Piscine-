/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: logafait <logafait@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/14 17:11:07 by logafait          #+#    #+#             */
/*   Updated: 2024/08/14 20:56:52 by logafait         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>

int	ft_len(char *s)
{
	int	i;

	i = 0;
	while (s[i])
		i++;
	return (i);
}

char	*ft_strcpy(char *p1, char *p2)
{
	int	i;

	i = 0;
	while (p2[i])
	{
		p1[i] = p2[i];
		i++;
	}
	p1[i] = '\0';
	return (p1);
}

int	strs_len(int size, char **strs, char *sep)
{
	int	i;
	int	len;
	int	sep_len;

	i = 0;
	len = 0;
	sep_len = ft_len(sep);
	while (i < size)
	{
		len += ft_len(strs[i]);
		if (i < size - 1)
			len += sep_len;
		i++;
	}
	return (len);
}

char	*ft_create_str(char **strs, int size, char *sep, int len)
{
	int		i;
	char	*s;

	i = 0;
	s = malloc(sizeof(char) * (len + 1));
	if (!s)
		return (NULL);
	while (i < size)
	{
		s = ft_strcpy(s, strs[i]);
		s += ft_len(strs[i]);
		if (i < size - 1)
		{
			s = ft_strcpy(s, sep);
			s += ft_len(sep);
		}
		i++;
	}
	*s = '\0';
	return (s - len);
}

char	*ft_strjoin(int size, char **strs, char *sep)
{
	int		len;
	char	*s;

	len = strs_len(size, strs, sep);
	if (size <= 0)
	{
		s = malloc(1);
		if (s)
			s[0] = '\0';
		return (s);
	}
	return (ft_create_str(strs, size, sep, len));
}
