#!/bin/bash
git ls-files --others --ignored --exclude-standard