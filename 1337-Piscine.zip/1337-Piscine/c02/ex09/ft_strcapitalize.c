/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcapitalize.c                                 :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: logafait <logafait@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/27 17:00:36 by logafait          #+#    #+#             */
/*   Updated: 2024/08/14 20:46:28 by logafait         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcapitalize(char *str)
{
	int	i;
	int	f;

	i = 0;
	f = 1;
	while (str[i])
	{
		if ((str[i] >= 'a' && str[i] <= 'z') || (str[i] >= 'A' && str[i] <= 'Z')
			|| (str[i] >= '0' && str[i] <= '9'))
		{
			if (f && (str[i] >= 'a' && str[i] <= 'z'))
				str[i] -= 32;
			else if (!f && (str[i] >= 'A' && str[i] <= 'Z'))
				str[i] += 32;
			f = 0;
		}
		else
			f = 1;
		i++;
	}
	return (str);
}
